import { AnimatePresence } from "framer-motion";
import Footer from "GlobalComponents/Footer";
import Header from "GlobalComponents/Header";
import { useSelector } from "react-redux";
import { wrapper } from "../Redux/store";
import "../styles/style.scss";

const MyApp = ({ Component, pageProps }) => <ExternalUtilities AllPages={<Component {...pageProps} />} />

const ExternalUtilities = ({ AllPages }) => {
  const { header, footer } = useSelector(state => state.GlobalVariables)
  return (
    <div className="Main_Blog_App">
      {header && <Header />}
      <AnimatePresence
            exitBeforeEnter
            initial={false}
            onExitComplete={() => window.scrollTo(0, 0)}
        >
            {AllPages}
      </AnimatePresence>
      {footer && <Footer />}
    </div>
  );
};

export default wrapper.withRedux(MyApp);

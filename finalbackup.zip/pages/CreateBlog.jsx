import EditorComp from "EditorComp";
import PageTransitionLayout from "GlobalComponents/PageTransitionLayout";
import { useState } from "react";
import BlogApi from "../Utils/BlogApi";

const CreateBlog = () => {
    const [Blog, setBlog] = useState({
        title: "",
        content: "",
        Author: "",
        description: "",
        image: "",
        createdAt: ""
    });
    const Upload = async (setLoading, Blog, clear) => {
        setLoading(true);
        const h = new Date()
        try {
            await BlogApi.UploadBlog({
                ...Blog,
                createdAt: h.getTime()
            });
            console.log("Uploaded");
        } catch (error) {
            console.log("Error");
            console.log(error);
        }
        setBlog({
            title: "",
            content: "",
            Author: "",
            description: "",
            image: "",
        });
        setLoading(false);
        clear()
    };
    return (
        <PageTransitionLayout>
            <div className="CreateBlog">
                <EditorComp Upload={Upload} context={{ Blog, setBlog }} />
            </div>
        </PageTransitionLayout>
    );
};

export default CreateBlog;

import Head from "next/head"
import PageTransitionLayout from "../../Components/GlobalComponents/PageTransitionLayout"


const Profile = () => {
  
  return (
    <PageTransitionLayout>
      <Head>
        <title>Profile</title>
      </Head>
        Profile
    </PageTransitionLayout>
  )
}

export default Profile
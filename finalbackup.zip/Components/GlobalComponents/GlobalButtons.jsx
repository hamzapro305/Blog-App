import Image from "next/image";
import { BUTTON_BUFFER } from "../../Assets";

const GlobalMainButton = ({
    disabled,
    onClick,
    children,
    cssClass,
    isLoading,
}) => (
    <button
        disabled={disabled === true ? true : false}
        className={`GlobalMainButton ${cssClass ? cssClass : ""}`}
        onClick={() => {
            if (isLoading) return;
            onClick ? onClick() : ""
        }}
    >
        {isLoading ? <Image src={BUTTON_BUFFER} width="80" height="20" objectFit="cover" /> : children}
    </button>
);

const GlobalDarkButton = ({ disabled, onClick, children, cssClass }) => (
    <button
        disabled={disabled === true ? true : false}
        className={`GlobalDarkButton ${cssClass ? cssClass : ""}`}
        onClick={onClick}
    >
        {children}
    </button>
);

const GlobalLightButton = ({ disabled, onClick, children, cssClass }) => (
    <button
        disabled={disabled === true ? true : false}
        className={`GlobalLightButton ${cssClass ? cssClass : ""}`}
        onClick={onClick}
    >
        <p>{children}</p>
    </button>
);

const GlobalCheckBox = ({ dependsOn, onClick, isLoading }) => (
    <div
        className="GlobalCheckBox"
        onClick={() => {
            if (isLoading) return;
            onClick();
        }}
        style={{
            justifyContent: dependsOn ? "flex-end" : "flex-start",
            cursor: isLoading ? "progress" : "pointer",
        }}
    >
        <div className={`ball ${dependsOn ? "on" : ""}`}></div>
    </div>
);

export {
    GlobalMainButton,
    GlobalDarkButton,
    GlobalLightButton,
    GlobalCheckBox,
};

import BUTTON_BUFFER from "./Global/BUTTON_BUFFER.gif";
import PLACE_HOLDER from "./Global/PLACE_HOLDER.png";

export { BUTTON_BUFFER, PLACE_HOLDER };
